<?php
include_once 'constantes.php';

/* ==========================================================
   CONEXIONES MYSQLi
   ========================================================== */

function getConexionMySQLi() {
    $mysqli = new mysqli(HOST, USERNAME, PASSWORD, DATABASE);
    if ($mysqli->connect_error) {
        die("Error de conexión MySQLi: " . $mysqli->connect_error);
    }
    $mysqli->set_charset("utf8");
    return $mysqli;
}

function getConexionMySQLi_sin_bbdd() {
    $mysqli = new mysqli(HOST, USERNAME, PASSWORD);
    if ($mysqli->connect_error) {
        die("Error de conexión MySQLi (Sin BBDD): " . $mysqli->connect_error);
    }
    return $mysqli;
}

/* ==========================================================
   CREACIÓN BBDD Y TABLAS (MySQLi)
   ========================================================== */

function crearBBDD_MySQLi($basedatos) {
    $mysqli = getConexionMySQLi_sin_bbdd();
    $sql = "CREATE DATABASE IF NOT EXISTS $basedatos CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
    $res = $mysqli->query($sql);
    $mysqli->close();
    return $res ? 0 : 1; 
}

function crearTablas_MySQLi($basedatos) {
    $mysqli = new mysqli(HOST, USERNAME, PASSWORD, $basedatos);
    if ($mysqli->connect_error) return 0;

    // 1. Tabla Logins
    $sql1 = "CREATE TABLE IF NOT EXISTS logins (
        usuario varchar(50) NOT NULL PRIMARY KEY,
        passwd varchar(255) NOT NULL
    )";
    $mysqli->query($sql1);

    // Insertamos usuario por defecto (nieves / 1234) si no existe
    $pass = md5('1234');
    $mysqli->query("INSERT IGNORE INTO logins VALUES ('nieves', '$pass')");

    // 2. Tabla Libros
    $sql2 = "CREATE TABLE IF NOT EXISTS libros (
        numero_ejemplar int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
        titulo varchar(50) NOT NULL,
        anyo_edicion int(11) NOT NULL,
        precio decimal(10,2) NOT NULL,
        fecha_adquisicion date NOT NULL
    )";
    $res = $mysqli->query($sql2);
    
    $mysqli->close();
    return $res ? 1 : 0;
}

// Funciones vacías de PDO para que no den error si se llaman accidentalmente
function crearBBDD($basedatos) { return 0; }
function crearTablas($basedatos) { return 1; }

/* ==========================================================
   USUARIOS: LOGIN Y REGISTRO (MySQLi)
   ========================================================== */

function usuarioCorrecto_MySQLi($usuario, $password) {
    $mysqli = getConexionMySQLi();
    $pass_md5 = md5($password);
    
    $stmt = $mysqli->prepare("SELECT usuario FROM logins WHERE usuario = ? AND passwd = ?");
    $stmt->bind_param("ss", $usuario, $pass_md5);
    $stmt->execute();
    $stmt->store_result();
    
    $existe = ($stmt->num_rows > 0);
    
    $stmt->close();
    $mysqli->close();
    return $existe;
}

function registrarUsuario_MySQLi($usuario, $password) {
    $mysqli = getConexionMySQLi();
    
    // 1. Comprobar si ya existe
    $stmt = $mysqli->prepare("SELECT usuario FROM logins WHERE usuario = ?");
    $stmt->bind_param("s", $usuario);
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows > 0) {
        $stmt->close();
        $mysqli->close();
        return false; // El usuario ya existe
    }
    $stmt->close();

    // 2. Insertar nuevo usuario
    $pass_md5 = md5($password);
    $stmt2 = $mysqli->prepare("INSERT INTO logins (usuario, passwd) VALUES (?, ?)");
    $stmt2->bind_param("ss", $usuario, $pass_md5);
    $ok = $stmt2->execute();
    
    $stmt2->close();
    $mysqli->close();
    return $ok;
}

/* ==========================================================
   GESTIÓN LIBROS: INSERTAR, LISTAR, BORRAR (MySQLi)
   ========================================================== */

function insertarLibro_MySQLi($titulo, $anyo, $precio, $fechaAdquisicion) {
    $mysqli = getConexionMySQLi();
    $stmt = $mysqli->prepare("INSERT INTO libros (titulo, anyo_edicion, precio, fecha_adquisicion) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("sids", $titulo, $anyo, $precio, $fechaAdquisicion);
    $ok = $stmt->execute();
    
    $stmt->close();
    $mysqli->close();
    return $ok;
}

function getLibros_MySQLi() {
    $mysqli = getConexionMySQLi();
    $result = $mysqli->query("SELECT * FROM libros");
    
    $libros = [];
    while ($obj = $result->fetch_object()) {
        $libros[] = $obj;
    }
    
    $mysqli->close();
    return $libros;
}

function getLibrosTitulo_MySQLi() {
    $mysqli = getConexionMySQLi();
    $result = $mysqli->query("SELECT DISTINCT titulo FROM libros");
    
    $titulos = [];
    while ($row = $result->fetch_row()) {
        $titulos[] = $row[0];
    }
    
    $mysqli->close();
    return $titulos;
}

function borrarLibro_MySQLi($numeroEjemplar) {
    $mysqli = getConexionMySQLi();
    $precio = null;
    
    // 1. Obtener precio
    $stmt = $mysqli->prepare("SELECT precio FROM libros WHERE numero_ejemplar = ?");
    $stmt->bind_param("i", $numeroEjemplar);
    $stmt->execute();
    $stmt->bind_result($p);
    
    if($stmt->fetch()) {
        $precio = $p;
    }
    $stmt->close();

    // 2. Borrar
    if ($precio !== null) {
        $stmtDel = $mysqli->prepare("DELETE FROM libros WHERE numero_ejemplar = ?");
        $stmtDel->bind_param("i", $numeroEjemplar);
        $stmtDel->execute();
        $stmtDel->close();
    }
    
    $mysqli->close();
    return $precio;
}

/* ==========================================================
   ACTUALIZACIÓN DE LIBROS (MySQLi)
   ========================================================== */

function modificarLibroAnyo_MySQLi($numero_ejemplar, $anyo_edicion) {
    $mysqli = getConexionMySQLi();
    $stmt = $mysqli->prepare("UPDATE libros SET anyo_edicion = ? WHERE numero_ejemplar = ?");
    
    if (is_array($numero_ejemplar)) {
        for ($i = 0; $i < count($numero_ejemplar); $i++) {
            $id = $numero_ejemplar[$i];
            $anyo = $anyo_edicion[$i];
            $stmt->bind_param("ii", $anyo, $id);
            $stmt->execute();
        }
    } else {
        $stmt->bind_param("ii", $anyo_edicion, $numero_ejemplar);
        $stmt->execute();
    }
    
    $stmt->close();
    $mysqli->close();
}

function getLibrosAnyo_MySQLi($titulo) {
    $mysqli = getConexionMySQLi();
    $stmt = $mysqli->prepare("SELECT * FROM libros WHERE titulo = ?");
    $stmt->bind_param("s", $titulo);
    $stmt->execute();
    
    $res = $stmt->get_result();
    $libros = [];
    while ($row = $res->fetch_assoc()) {
        $libros[] = $row;
    }
    
    $mysqli->close();
    return $libros;
}

function getLibrosPrecio_MySQLi($libro) {
    return getLibrosAnyo_MySQLi($libro);
}

function modificarLibro_MySQLi($numero_ejemplar, $precio) {
    $mysqli = getConexionMySQLi();
    $stmt = $mysqli->prepare("UPDATE libros SET precio = ? WHERE numero_ejemplar = ?");
    $stmt->bind_param("di", $precio, $numero_ejemplar);
    $stmt->execute();
    $mysqli->close();
}

function arrayFlotante($array) {
    $aux = [];
    foreach($array as $a) {
        $aux[] = floatval($a);
    }
    return $aux;
}

?>