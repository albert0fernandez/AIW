<?php
session_start();
include 'connect.php';

// Seguridad: Bloqueo de acceso directo si no hay sesión activa
if (!isset($_SESSION['usuario'])) {
    header("Location: index.php");
    exit();
}

// --- LÓGICA DE BORRADO (DELETE) ---
if (isset($_GET['borrar'])) {
    $id_borrar = $_GET['borrar'];
    // Ejecutamos el DELETE en la base de datos
    $sql_borrar = "DELETE FROM aplicaciones WHERE id_aplicacion = '$id_borrar'";
    $conn->query($sql_borrar);
    // Redirigimos a la misma página para limpiar la URL y refrescar la lista
    header("Location: aplicaciones.php");
    exit();
}

//// --- LÓGICA DE INSERCIÓN (CREATE) ---
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre_app'];
    $desc = $_POST['desc_app'];

    if (!empty($nombre) && !empty($desc)) {
        $sql_insert = "INSERT INTO aplicaciones (nombre_aplicacion, descripcion) VALUES ('$nombre', '$desc')";
        if ($conn->query($sql_insert) === TRUE) {
            // Éxito
        } else {
            echo "Error al insertar: " . $conn->error;
        }
    }
}

// 
$sql = "SELECT * FROM aplicaciones";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Gestión de Aplicaciones</title>
</head>
<body>
    <center>
        <h1>Gestión de Aplicaciones</h1>

        <div style="border: 1px solid #ccc; padding: 20px; width: 50%; margin-bottom: 30px;">
            <h3>Añadir Nueva Aplicación</h3>
            <form method="post" action="">
                Nombre: <input type="text" name="nombre_app" required>
                Descripción: <input type="text" name="desc_app" required>
                <input type="submit" value="Guardar">
            </form>
        </div>

        <h2>Listado Actual</h2>
        <table border="1" cellpadding="10">
            <tr>
                <th>ID</th>
                <th>Nombre Aplicación</th>
                <th>Descripción</th>
                <th>Acción</th> </tr>
            
            <?php
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["id_aplicacion"] . "</td>";
                    echo "<td>" . $row["nombre_aplicacion"] . "</td>";
                    echo "<td>" . $row["descripcion"] . "</td>";
                    
                    // BOTÓN DE BORRAR (Con confirmación de seguridad)
                    echo "<td>";
                    echo "<a href='aplicaciones.php?borrar=" . $row["id_aplicacion"] . "' onclick='return confirm(\"¿Estás seguro de querer borrar esta aplicación?\");' style='color: red;'>Borrar</a>";
                    echo "</td>";
                    
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='4'>No hay aplicaciones registradas</td></tr>";
            }
            ?>
        </table>
        
        <br><br>
        <a href="principal.php">Volver al Menú Principal</a>
    </center>
</body>
</html>