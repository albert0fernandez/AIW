<?php
// Configuración de credenciales de la base de datos
$servername = "localhost";
$username = "admin";
$password = "1234";
$dbname = "gestion_aplicaciones";

// Instanciamos el objeto mysqli para crear la conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Validación estricta de la conexión antes de continuar
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>
