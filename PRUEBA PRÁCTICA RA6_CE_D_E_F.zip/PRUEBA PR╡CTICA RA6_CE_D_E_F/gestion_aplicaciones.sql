CREATE DATABASE IF NOT EXISTS gestion_aplicaciones;
USE gestion_aplicaciones;

-- Tabla de Usuarios
CREATE TABLE IF NOT EXISTS logins (
    usuario VARCHAR(50) PRIMARY KEY,
    passwd VARCHAR(32) NOT NULL
);

-- Tabla de Aplicaciones
CREATE TABLE IF NOT EXISTS aplicaciones (
    id_aplicacion INT AUTO_INCREMENT PRIMARY KEY,
    nombre_aplicacion VARCHAR(50) NOT NULL,
    descripcion VARCHAR(300)
);

-- Tabla de Permisos 
CREATE TABLE IF NOT EXISTS permisos (
    usuario VARCHAR(50),
    id_aplicacion INT,
    PRIMARY KEY (usuario, id_aplicacion),
    FOREIGN KEY (usuario) REFERENCES logins(usuario) ON DELETE CASCADE,
    FOREIGN KEY (id_aplicacion) REFERENCES aplicaciones(id_aplicacion) ON DELETE CASCADE
);

INSERT INTO logins (usuario, passwd) VALUES ('admin', 'admin123');
INSERT INTO logins (usuario, passwd) VALUES ('usuario1', 'pass123');

INSERT INTO aplicaciones (nombre_aplicacion, descripcion) VALUES 
('App Ventas', 'Sistema de gestión de ventas'),
('App Inventario', 'Control de inventario');
