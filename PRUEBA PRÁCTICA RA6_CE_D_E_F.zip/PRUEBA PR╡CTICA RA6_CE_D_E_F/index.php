// Inicia la sesión para persistir datos del usuario entre páginas
<?php
session_start();
include 'connect.php';
$error = "";
// Lógica de Autenticación (Método POST)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user = $_POST['usuario'];
    $pass = $_POST['contraseña'];

// Consulta SQL para validar credenciales (Usuario y Password)
    $sql = "SELECT * FROM logins WHERE usuario = '$user' AND passwd = '$pass'";
    $result = $conn->query($sql);
// Si devuelve filas, el usuario existe
    if ($result->num_rows > 0) {
        // 
        $_SESSION['usuario'] = $user;
        header("Location: principal.php");
        exit();
    } else {
        $error = "Usuario o contraseña incorrectos.";
    }
}
?>

<!DOCTYPE html>
<html>
<head><title>Login</title></head>
<body>
    <center>
        <div style="margin-top: 50px;">
            <h2>Bienvenido a la aplicación de gestión de permisos</h2>
            
            <form method="post" action="">
                Usuario: <input type="text" name="usuario" required><br><br>
                Contraseña: <input type="password" name="contraseña" required><br><br>
                <input type="submit" value="Login">
            </form>
            
            <p style="color:red;"><?php echo $error; ?></p>
            
            <br>
            <a href="registrarse.php">Registrarse</a>
        </div>
    </center>
</body>
</html>