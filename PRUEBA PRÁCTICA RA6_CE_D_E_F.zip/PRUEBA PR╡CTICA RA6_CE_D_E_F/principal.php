<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head><title>Principal</title></head>
<body>
    <center>
        <h1>Bienvenido a la aplicación de gestión de permisos</h1>
        <ul>
            <li><a href="aplicaciones.php">Gestion de aplicaciones</a></li>
        </ul>
        <br><br>
        <a href="logout.php">Cerrar Sesión</a>
    </center>
</body>
</html>