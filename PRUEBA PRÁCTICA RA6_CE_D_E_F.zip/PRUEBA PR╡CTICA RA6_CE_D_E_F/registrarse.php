<?php
include 'connect.php'; 
$mensaje = "";

// Recogida de datos del formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario = $_POST['usuario'];
    $pass1 = $_POST['pass1'];
    $pass2 = $_POST['pass2'];
// Validación: Las contraseñas deben coincidir antes de tocar la BD
    if ($pass1 === $pass2) {
        
        // Tabla: logins, Columnas: usuario, passwd
        $sql = "INSERT INTO logins (usuario, passwd) VALUES ('$usuario', '$pass1')";
        
        if ($conn->query($sql) === TRUE) {
            $mensaje = "<h3>Insertado con exito.</h3><br><a href='index.php'>Hacer Login</a>";
        } else {
            
            $mensaje = "Error: " . $conn->error;
        }
    } else {
        $mensaje = "Las contraseñas no coinciden.";
    }
}
?>

<!DOCTYPE html>
<html>
<head><title>Registro</title></head>
<body>
    <center>
        <?php if ($mensaje != ""): ?>
            <div style="margin-top: 50px;">
                <h2>Aplicacion de permisos - Registro</h2>
                <?php echo $mensaje; ?>
            </div>
        
        <?php else: ?>
            <div style="margin-top: 50px;">
                <h2>Aplicacion de permisos - Registro</h2>
                <form method="post" action="">
                    Usuario: <input type="text" name="usuario" required><br><br>
                    Contraseña: <input type="password" name="pass1" required><br><br>
                    Repita la contraseña: <input type="password" name="pass2" required><br><br>
                    <input type="submit" value="Registrar">
                </form>
                <br>
                <a href="index.php">Volver al Login</a>
            </div>
        <?php endif; ?>
    </center>
</body>
</html>